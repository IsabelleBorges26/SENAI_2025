DROP DATABASE IF EXISTS locadora;
CREATE DATABASE locadora;
USE locadora;

CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(20) NOT NULL
);

CREATE TABLE veiculos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modelo VARCHAR(100) NOT NULL,
    placa VARCHAR(10) NOT NULL,
    categoria VARCHAR(20) NOT NULL
);

CREATE TABLE contratos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id int,
    veiculo_id int,
    data_inicio DATE NOT NULL,
    data_fim DATE NOT NULL,
    valor DECIMAL(10) NOT NULL,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (veiculo_id) REFERENCES veiculos(id)

);

CREATE TABLE manutencoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    veiculo_id int,
    tipo VARCHAR(100) NOT NULL,
    data DATE NOT NULL,
    observação VARCHAR(100) NOT NULL,
    FOREIGN KEY (veiculo_id) REFERENCES veiculos(id)
);

INSERT INTO clientes
VALUES 
(DEFAULT, "Isabelle", "23045865860");

INSERT INTO veiculos
VALUES 
(DEFAULT, "Cooper", "12345", "Hatch Premium");

INSERT INTO contratos
VALUES 
(DEFAULT, 1, 1, "2025-09-02", "2025-09-30", "239.990");

INSERT INTO manutencoes
VALUES 
(DEFAULT, 1, "Trocar pneu", "2026-09-30", "Colocar pneu baratinho");





