DROP DATABASE IF EXISTS empresa;
CREATE DATABASE empresa;
USE empresa;

CREATE TABLE departamento (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) 
);

CREATE TABLE funcionarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(50),
  cargo VARCHAR(50),
  departamento_ID INT,
  FOREIGN KEY (departamento_ID) REFERENCES departamento(id)
);

INSERT INTO departamento
VALUES 
(DEFAULT, "SENAI");

INSERT INTO funcionarios
VALUES 
(DEFAULT, "Robson", "Professor", 1);

