DROP DATABASE IF EXISTS appmusica;
CREATE DATABASE appmusica;
USE appmusica;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(50) NOT NULL
);

CREATE TABLE playlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    nome VARCHAR(100) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE musicas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    artista VARCHAR(100) NOT NULL,
    duração VARCHAR(6) NOT NULL
);

CREATE TABLE playlistmusica (
    ordem INT NOT NULL,
    id INT AUTO_INCREMENT PRIMARY KEY,
    musica_id INT,
    playlist_id INT,
    FOREIGN KEY (musica_id) REFERENCES musicas(id),
    FOREIGN KEY (playlist_id) REFERENCES playlist(id)
);

INSERT INTO usuarios
VALUES 
(DEFAULT, "Isabelle", "manuborges2612@gmail.com");

INSERT INTO playlist
VALUES 
(DEFAULT, 1, "Rock de pai divorciado");

INSERT INTO musicas
VALUES 
(DEFAULT, "Dirty Deeds Done Dirt Cheap", "AC/DC", "3:56");

INSERT INTO playlistmusica
VALUES 
(1, DEFAULT, 1, 1);
