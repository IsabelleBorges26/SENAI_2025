DROP DATABASE IF EXISTS faculdade;
CREATE DATABASE faculdade;
USE faculdade;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100)
);

CREATE TABLE cursos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(100)
);

CREATE TABLE aulas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  curso_id INT,
  titulo VARCHAR(100),
  FOREIGN KEY (curso_id) REFERENCES cursos(id)
);

CREATE TABLE progresso (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT,
  aula_id INT,
  status VARCHAR(20),
  data_conclusao DATE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (aula_id) REFERENCES aulas(id)
);

INSERT INTO usuarios
VALUES 
(DEFAULT, "Isabelle");

INSERT INTO cursos
VALUES 
(DEFAULT, "Engenharia de Software");

INSERT INTO aulas
VALUES 
(DEFAULT, 1, "Banco de Dados");

INSERT INTO progresso
VALUES 
(DEFAULT, 1, 1, "Aprovada", "2031-12-30");



