DROP DATABASE IF EXISTS escola;
CREATE DATABASE escola;
USE escola;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100)
);

CREAtE TABLE cursos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(100)
);

CREATE TABLE aulas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  curso_id INT,
  titulo VARCHAR(100),
  FOREIGN KEY (curso_id) REFERENCES cursos(id)
);

CREATE TABLE progresso (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT,
  aula_id INT,
  status VARCHAR(20),
  data_conclusao DATE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (aula_id) REFERENCES aulas(id)
);

INSERT INTO usuarios
VALUES 
(DEFAULT, "Guilherme");

INSERT INTO cursos
VALUES 
(DEFAULT, "Engenharia de Software");

INSERT INTO aulas
VALUES 
(DEFAULT, 1, "Back-End");

INSERT INTO progresso
VALUES 
(DEFAULT, 1, 1, "Aprovado", "2030-12-30");
