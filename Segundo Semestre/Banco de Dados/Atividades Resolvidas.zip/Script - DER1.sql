DROP DATABASE IF EXISTS escola;
CREATE DATABASE escola;
USE escola;

CREATE TABLE professores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(50) NOT NULL,
    telefone VARCHAR(15) NOT NULL
);

CREATE TABLE disciplinas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    professor_id INT,
    nome VARCHAR(100) NOT NULL,
    FOREIGN KEY (professor_id) REFERENCES professores(id)
);

CREATE TABLE turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    periodo VARCHAR(10) NOT NULL,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE ids (
    turma_id INT NOT NULL,
    disciplina_id INT NOT NULL,
    FOREIGN KEY (disciplina_id) REFERENCES disciplinas(id),
    FOREIGN KEY (turma_id) REFERENCES turmas(id)
);

INSERT INTO professores
VALUES 
(DEFAULT, "Reenye", "reenye.lima@senaisp.edu.br", "19999999999");

INSERT INTO disciplinas
VALUES 
(DEFAULT, 1, "Bando de Dados");

INSERT INTO turmas
VALUES 
(DEFAULT, "Integral", "2B");

INSERT INTO ids
VALUES 
(1, 1);
