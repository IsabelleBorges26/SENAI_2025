const musicas = [

    {
        "id": "123",
        "titulo": "Dirty Deeds Done Dirt Cheap",
        "artista": "AC/DC",
        "duracao": "3:50",
    },

    {
        "id": "456",
        "titulo": "Let Me Put My Love Into You",
        "artista": "AC/DC",
        "duracao": "4:12",
    }

];

module.exports = musicas;