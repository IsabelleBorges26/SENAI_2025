const usuarios = [

    {
        "id": "123",
        "nome": "Isabelle",
        "email": "Isabelle@gmail",
    },

    {
        "id": "456",
        "nome": "Guilherme",
        "email": "Guillherme@gmail",
    }

];

module.exports = usuarios;