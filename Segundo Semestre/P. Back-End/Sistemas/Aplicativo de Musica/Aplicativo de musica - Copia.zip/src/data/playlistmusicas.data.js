const playlistmusicas = [

    {
        "ordem": "1",
        "id": "123",
        "musica_id": "123",
        "playlist_id": "1",
    },

    {
        "ordem": "2",
        "id": "456",
        "musica_id": "456",
        "playlist_id": "2",
    }

];

module.exports = playlistmusicas;