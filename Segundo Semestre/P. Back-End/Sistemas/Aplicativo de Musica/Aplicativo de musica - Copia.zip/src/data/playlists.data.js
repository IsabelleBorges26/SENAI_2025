const playlist = [

    {
        "id": "123",
        "usuario_id": "123",
        "nome": "Classicas🎻",
    },

    {
        "id": "456",
        "usuario_id": "456",
        "nome": "Rock🎸",
    }

];

module.exports = playlist;